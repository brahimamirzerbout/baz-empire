/*
 * Copyright (C) 2011 Igalia S.L.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY APPLE INC. AND ITS CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL APPLE INC. OR ITS CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

#if !defined(__WEBKIT_H_INSIDE__) && !defined(__WEBKIT_WEB_PROCESS_EXTENSION_H_INSIDE__) && !defined(BUILDING_WEBKIT)
#error "Only <webkit2/webkit2.h> can be included directly."
#endif

#ifndef WebKitDefines_h
#define WebKitDefines_h

#include <glib.h>

#ifdef G_OS_WIN32
#    ifdef BUILDING_WEBKIT
#        define WEBKIT_API __declspec(dllexport)
#    else
#        define WEBKIT_API __declspec(dllimport)
#    endif
#else
#    define WEBKIT_API __attribute__((visibility("default")))
#endif

#define WEBKIT_DEPRECATED WEBKIT_API G_DEPRECATED
#define WEBKIT_DEPRECATED_FOR(f) WEBKIT_API G_DEPRECATED_FOR(f)

/**
 * WEBKIT_DEPRECATED_FOR: (skip)
 * @f: replacement symbol name
 *
 * Marks a symbol as deprecated, indicating a replacement.
 */


#define WEBKIT_DECLARE_TYPE(ModuleObjName, module_obj_name, MODULE, OBJ_NAME, ParentName) \
    WEBKIT_API GType module_obj_name ## _get_type (void);                  \
                                                                           \
    typedef struct _ ## ModuleObjName ModuleObjName;                       \
    typedef struct _ ## ModuleObjName ## Class ModuleObjName ## Class;     \
    typedef struct _ ## ModuleObjName ## Private ModuleObjName ## Private; \
                                                                           \
    struct _ ## ModuleObjName {                                            \
        ParentName parent;                                                 \
        /*< private >*/                                                    \
        ModuleObjName ## Private *priv;                                    \
    };

#define WEBKIT_DECLARE_DERIVABLE_TYPE WEBKIT_DECLARE_TYPE
#define WEBKIT_DECLARE_FINAL_TYPE WEBKIT_DECLARE_TYPE


#endif /* WebKitDefines_h */
